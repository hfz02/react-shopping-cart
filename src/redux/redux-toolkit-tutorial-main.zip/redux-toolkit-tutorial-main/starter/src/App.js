function App() {
  return <h2>Redux Toolkit</h2>;
}
export default App;
